import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState, AppThunk } from '../../app/store';
import { Iimages } from '../../models/IImg';
import { getImages } from './galAPI';

const initialState: Iimages = {
    images: []
};

export const getImagesAsync = createAsyncThunk(
  'gal/getImages',
  async () => {
    const response = await getImages();
    return response.data;
  }
);

export const galSlice = createSlice({
  name: 'gal',
  initialState,
  reducers: {
  },

  extraReducers: (builder) => {
    builder
      .addCase(getImagesAsync.fulfilled, (state, action) => {
        console.log(action.payload)
        state.images=action.payload
      });
  },
});

export const { } = galSlice.actions;
export const selectImages = (state: RootState) => state.gal.images;
export default galSlice.reducer;
