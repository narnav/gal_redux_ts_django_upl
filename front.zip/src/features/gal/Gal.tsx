import React, { useEffect, useState } from 'react';
import { useAppSelector, useAppDispatch } from '../../app/hooks';
import {getImagesAsync,selectImages} from './galSlice';
import styles from './Counter.module.css';

export const Gal=()=> {
  const images = useAppSelector(selectImages);
  const dispatch = useAppDispatch();
    useEffect(() => {dispatch(getImagesAsync()) }, [])

  return (
    <div>
        Images
        {images.map((img,i)=><div>{img.desc}<img src={`http://127.0.0.1:8000/${img.image}`}></img></div>)}
    </div>
  );
}
